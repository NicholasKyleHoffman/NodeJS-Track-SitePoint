// // variables being with: var, let, or const
// // Syntax var varName = value;
// // JS = Dynamically typed language - var type is inferred from value assigned to it
// // cannot be reserved keywords | must start with: $, an underscore: ' _ ', or letter
//
// // error: cannot begin with a #
// // var 1variable = "1 variable";
//
// // // error: res. keywords
// // var var = "variable";
//
// // camelCase is preferred
// var firstName = "nick";
// var lastName = "hoffman"
// var gradesToBeCounted = 4; // vs var gradestobecounted = 4;
//
// // number
// var itemsInCart = 4;
//
// // bool
// var cartIsEmpty = false;
//
// // multiple ways to print
// console.log(firstName + " " + lastName);
// console.log(firstName, lastName);
//
// // ES6: template string literals
// console.log(`${firstName} ${lastName}`);
// console.log(`The IT Dir name is ${firstName}`);
//
// var fullName = firstName + " " + lastName;
// console.log(fullName);

// var || let || const
// let variable can't be redeclared after initial use. SCOPED to specific code block.
// var is available globaly
var dogName = "emma";
var dogName = "sophie"; // sophie prints

let catName = "pickles";
console.log(catName);
// let catName = "someNewone"; // ERROR: ID catName already declared (breaks above rule)
// console.log(catName);

// you CAN reassign let value, not re-declare with let, though.
catName = "someNewone";
console.log(catName);

// CONSTANT. does not change.
const employee = "Nick Hoffman";
let position = "Software Dev";
let salary = 60,000;
let areaCode = 852;
const birthDate = "5.5.55";

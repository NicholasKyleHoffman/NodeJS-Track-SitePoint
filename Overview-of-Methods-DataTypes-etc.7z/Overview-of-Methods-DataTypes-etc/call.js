let obj = {
  num: 2
};

let addToThis = function(a,b,c){
  // this has no context here
  return this.num + a + b + c; // this.num out of scope (due to let)
};

// call binds the function to first
// obj. passed in. Params are passed in
//subseq. vals
console.log(addToThis.call(obj, 1, 2, 3));

let person1 = {
  firstN: "nicole",
  secondN: "g"
};

let person2 = {
  firstN: "nick",
  secondN: "perso"
};

function hello(greeting) {
  console.log(`${greeting} ${this.firstN} ${this.secondN}`);
}

// NOTE 'this' is regained via function hello(greeting){}
hello.call(person1, 'howdy');
hello.call(person2, 'hello there');

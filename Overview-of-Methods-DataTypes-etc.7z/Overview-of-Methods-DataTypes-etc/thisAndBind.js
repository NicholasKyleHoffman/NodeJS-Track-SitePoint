// in JS - 'this' is the obj. that owns the object's JS code

let hotRod = {};

// <= es6 syntax
hotRod = {
  sound: 'vroooom',
  soundOff: function() {
    console.log(this.sound);
  }
};

hotRod.soundOff();

// 'this' loses its context here!!!!!!!!!!
// (undefined returned)
let soundFunction = hotRod.soundOff;
soundFunction();

// workaround: we can 'BIND' 'this' to the obj. hotRod
// this will give soundFunction a 'this' context
let bindSoundFunction = soundFunction.bind(hotRod);
bindSoundFunction();

let person1 = {
  name: 'joe'
}

let person2 = {
  name: 'jane'
}

function logName(){
  return this.name;
}

console.log(logName());
console.log(logName.bind(person1)());  // GOT 'this' context back
console.log(logName.bind(person2)());// GOT 'this' context back

let number = {
  x: 24,
  y: 22
};

// no 'this' context as let is scoped to number obj.
let count = function() {
  console.log(this.x + this.y)
}

let bindCount = count.bind(number);
bindCount(); // returns x + y

bindCount(this.x + this.y); // also returns x + y

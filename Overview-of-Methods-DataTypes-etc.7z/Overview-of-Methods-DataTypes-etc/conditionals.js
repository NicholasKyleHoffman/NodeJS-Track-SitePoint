// loops with condit'ls
// w/conditionals we eval a condition & take a code path
// depending on val of condition

// if else if
let a = 9;
let b = 32;

if(a > b){ // false
  console.log('a > b')
} else if (a === b){ // false
  console.log("a != b") // true
} else {
  console.log("a < b") // true
}

// anything returns bool val can be the conditionals
if ((a + b) > (a * b - 248)) { // (42 > 40) TRUE
  console.log("condition is true") // TRUE
} else {
  console.log("condition is false")
}

// can chain muliple conditions together
// && = "and"
// || = "or"
if((true) && (true)){  // TRUE
  console.log("condition is true")
} else {
  console.log("condition is false")
}

// || comparison
if((true) || (false)){  // TRUE
  console.log("condition is true")
} else {
  console.log("condition is false")
}

// Switch statement
let color = 'red';

switch(color){
  case 'blue':
    console.log("Blue")
    break;
  case 'green':
    console.log("Green")
    break;
  case 'red':
    console.log("Red!")
    break;
  default:
  console.log('we couldn\'t determine the color');
}

// loops: code run over and over until some condition is arithmetics

// while loops
let counter = 5;
while(counter <= 10){
  console.log(`The value is ${counter++}`);
}

// do while loop
counter = 5;
do {
  console.log(`The value is ${counter}`);
  counter++;
} while (counter <= 7);

// for looop
for(let i=5; i<=10; i++){
  console.log(i)
}

// operators used for: assigning/comparing values, performing arithmetics

// TERNARY operators
// condition ? expr1 : expr2     ||  expr1 eval'd if condition == true ELSE expr2

// Binary operators - req. 2 operands
// 1 + 2
// a * b

// Unary operators
// Reqs one operand before, or after operators
// a++ (after)
// ++a (before)

let a = 1;
console.log(a++);
console.log(a);

console.log(++a);
console.log(a);

// Arith. ops: -, +, /, *, %
let total = 32 + 46 - 13; // 65
console.log(total);
let product = 5 * 5; // 25

let totalCost = 32.00; // assign value of 32.00 to totalCost

// Equality OPERATOR ==
// == -> compares EQUALITY ONLY
console.log(5 == 5); // true
console.log(5 == true); // false


// VS. Strict Equal. ===
// === -> compares EQUALITY & TYPE
console.log(5 === "5"); // false
console.log(1 === false); // false

// % (modulous) -> like div but only returns remainder of EVEN num
console.log(25 % 5); // 0
console.log(25 % 3); // 1

// USING % to find if # is EVEN or ODD
console.log(5 % 2 == 0); // FALSE -> returns 1, NOT 0
console.log(4 % 2 == 0); // TRUE -> returns 0, NOT 1 

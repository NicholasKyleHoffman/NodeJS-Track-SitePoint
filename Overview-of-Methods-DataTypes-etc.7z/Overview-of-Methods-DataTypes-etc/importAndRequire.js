// must know how to reuse code from ONE FILE
// to ANOTHER FILE
// es5 = require() -> old syntax****
// es6 = import() -> babel needs to transpile es6 to es5 (import & babel - npm run dev - package.json)

// IMPORT() EXAMPLE - NEWER syntax
// in order to run this - need babel
// ******  cmd line = npm run dev  ******
// ^ grabs 'dev' (from package.json) which allows babel to transpiling ES6 -> ES5 to use IMPORT SYNTAX
import { myVar, func1, func2 } from './export';

console.log(`The value of myVar = ${myVar}`);
func1();
func2();


// REQUIRE() EXAMPLE - OLD SYNTAX
// './' = current folder path
// let myFuncs = require('./export');
// console.log(`The value of myVar = ${myFuncs.myVar}`);
// // myVar vs. myVariable will return UNDEFINED or 942 (value of var in ./export file)
// // console.log(`The value of myVar = ${myFuncs.myVariable}`);
// myFuncs.func1();
// myFuncs.func2();


// IMPORT() EXAMPLE - new SYNTAX
// import module.export.js
// console.log(`import ex of myVar = ${myFuncs.myVar}`);

 // everything that isn't a primitive data type IS AN OBJECT
 // vars in objects = properties
 // functions in objects = methods
 // object = key:value store denoted by { }


 // 1. Obj. Literal
 var truck = {
   // properties
   make: "dodge",
   wheels: "4",
   model: "charger"
 }

 // access props via bracket OR Dot (.) notation
 // a) bracket notation:
 console.log(`I have a ${truck['make']} ${truck['model']}`);


// b) dot notation
console.log(`It has ${truck.wheels} wheels`);


// c) object Literal
var emp = {
  name:'chuck',
  id:'007',
  // methods
  empDetails: function(){
    return `${this.name} ${this.id}`;
  }
}

console.log(`Employee details = ${emp.empDetails()}`);


// Obj constructor function (if u have several instances of same Obj)
function Vehicle(make, model, year) {
  this.make = 'porsche';
  this.model = 'carrera';
  this.year = '1977';
  this.getFullDescription = () => `${this.make}, ${this.model}, ${this.year}`;
}

// Create new instances with new keyword
let myTruck = new Vehicle('Dodge','Ram','2000');
let mySedan = new Vehicle('Mazda','Miata',"1989");

console.log(myTruck.year,myTruck.make);
console.log(mySedan.make,mySedan.model,mySedan.year);
console.log(myTruck.getFullDescription());

// // function keyword decl. for object
// function createVehicle(make,model,year){
//   return {
//     make: make,
//     model: model,
//     year: year,
//     getFullDescription: function(){
//       // return `${this.make}, ${this.model}, ${this.year}`; // either way works
//       return `${make}, ${model}, ${year}`;
//     }
//   };
// }
//
// let myCar = createVehicle('honda','fit','2016');
//
// console.log(myCar.year,myCar.make,myCar.model);

// ES6 Enhanced Object Literal Syntax
// function keyword decl. for object
// this syntax doesn't req model: model or model = model for props.
function createVehicle(make,model,year) {
  return {
    make,
    model,
    year,
    getFullDescription() {
      // return `${this.make}, ${this.model}, ${this.year}`; // either way works
      return `${make}, ${model}, ${year}`;
    }
  };
}

let myCar2 = createVehicle('honda','rover','2001');
console.log(myCar2.year,myCar2.make,myCar2.model);

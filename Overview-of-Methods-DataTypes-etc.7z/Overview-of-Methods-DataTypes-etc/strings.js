// strings = data type representing text - ' ' or " "
let name = "Jack";
console.log(name);

name = 'Jane';
console.log(name);

let message = "it's nice to see you";
console.log(message);

message = 'it\'s nice to see you';
console.log(message);

// typeof returns type of OBJ
console.log(typeof 92); // num
console.log(typeof message); // strings
console.log(typeof true); // bool

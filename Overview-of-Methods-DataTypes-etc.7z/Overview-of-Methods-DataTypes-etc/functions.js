// JS functions do something
// ES6 syntax vs function declarations.
// functions perform a task & can be used over and over
// DRY - DON't REPEAT YOURSELF ^^^^ Reusability
// functions are first class Objects - but can be called vs Objects that can'// TEMP:

// THESE ARE HOISTED TO TOP OF FILE when we get to the function calls below
myFunction();
myFunctionWithParam('nick');

// NAMED FUNCTION
function myFunction(){
  console.log('hello');
}

myFunction();

// FUNCTION WITH PARAMS
function myFunctionWithParam(name){
  console.log('hello' + ' ' + name);
  console.log(`hello ${name}`);
}

// invoke function with param after declaration above
myFunctionWithParam('nick');
// invoke function after declaration above
myFunction();

// function w/mult. params & RETURN statement
function addThreeNums(a, b, c){
  return a + b + c;
}

let result = addThreeNums(1, 8, 7);
console.log(result);

// function w/mult. params & RETURN statement
function addThreeNums(a, b, c){
  console.log( a + b + c );
}

addThreeNums(1,8,7);


// IIFE -immediately invoked function examples - after declaration above
let sayGreeting2 = (function(){
  return 'hey what\'s up?';
}());

console.log(sayGreeting2);

// same, with params & different function name - vars passed @ end
let sayGreeting3 = (function(fName,lName){
  return `hey what\'s up, ${fName} ${lName}?`;
}('Bart','Bernard'));

console.log(sayGreeting3);

// ES6 below!

// ES6 arrow function syntax - arrow f's DON'T bind to 'this'
let sayBye = () => {
  return 'goodbye';
}
console.log(sayBye());

// convert speakNames to ES6 arrow
let speakNames = function(firstN,lastN){
    return `the names are ${firstN} & ${lastN}`;
}
console.log(speakNames('jack','jill'));

// ES6 - one code block - no need for return or open/close brackets
let speakNames2 = (firstN,lastN) => `the names are ${firstN} & ${lastN}`;
console.log(speakNames2('hucj','jill'));

// THIS keyword: refers to object in scope/object itself

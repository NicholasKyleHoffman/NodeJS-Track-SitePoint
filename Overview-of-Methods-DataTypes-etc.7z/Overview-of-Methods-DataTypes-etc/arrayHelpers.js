// Array Helper Methods
let arr = [32,5,2,12,54231,33,555,666];

// FOR loop
console.log("for loop====");
for(var x=0; x < arr.length; x++){
  console.log(arr[x]);
};

// FOR EACH
console.log("for each====");
  arr.forEach(function(arrayEl){
    console.log(arrayEl);
});

// FOR EACH Fat arrow
console.log("FOR EACH Fat arrow====");
  arr.forEach(value => console.log(value));

// Grades ex
console.log("GRADES====");
  let grades = [94,89,99,22,15,107];
  let sum = 0;

  grades.forEach(grade => sum += grade);

  let average = sum / grades.length;
  console.log(`The avg grade is ${average}`);


  // copy array to another addOne array
  // same solution as MAP below
  let array = [1,2,3,4,5];
  let addOne = [];
  for(let x=0; x < array.length; x++){
    addOne.push(array[x] + 1);
  }
  console.log("addOne", addOne);


  // MAP helper
  // iterate thru array, perform op on each elem.
  // One of the most commonly used helpers = MAP!
  let addOneMap = array.map(function(value) {
    return value + 1;
  });

  console.log("addOneMap", addOneMap);

  // MAP
  // arr of vehicle objects
  // remove objs using ES6 arrow functions
  let vehicles = [
    {
        id: 5,
        make:'dodge',
        model: 'ram',
        year: '1969',
        isAWD: true
    },
    {
      id: 2,
      make:'ferarri',
      model: 'italian',
      year: '1999',
      isAWD: false
    },
    {
      id: 1,
      make:'tesla',
      model: 'electric sedan',
      year: '2021',
      isAWD: false
    }
  ];

  let truckDriver = {
    id: 1,
    name: "Jack"
  }

  let models = vehicles.map(vehicle => vehicle.model);
  console.log(models);


  // FIND driverForVehicle WITH arrow function
  function findDriverForVehicle(vehicles, driver) {
      return vehicles.find(vehicle => vehicle.id === driver.id);
  }

  let driver = findDriverForVehicle(vehicles, truckDriver);
  console.log(`Truck Driver: ${truckDriver.name}, Driver ID: ${truckDriver.id} uses this vehicle`);


// // FIND driverForVehicle NO arrow
// (**not working**)
// function findDriverForVehicle(vehicles, truckDriver) {
//     return vehicles.find(function(vehicle) {
//     return vehicle.id === driver.id;
//   });
// }
//
// let driver = findDriverForVehicle(vehicles, truckDriver);
// console.log("driver uses vehicle with ID = 1", driver);

// FILTER method filters out certain arr elems
// remove objs using ES6 arrow functions
let matchingModels = vehicles.filter(vehicle => vehicle.make === "dodge");
console.log("FILTER WITH ARROW", matchingModels);


// Filter WITH RETURN
// get same result as above WITH arrow function
let filteredVehicles = vehicles.filter(function(vehicle){
  return vehicle.make === "dodge";
});

console.log("FILTER WITH RETURN", filteredVehicles);


// FIND (w.o. arrow function first)
let vehicleMakeFIND = vehicles.find(function(vehicle){
  return vehicle.make === "tesla";
})

console.log("FILTER WITH RETURN", vehicleMakeFIND);


// FIND with Arrow ES6 function syntax
let vehicleArrowFind = vehicles.find(vehicle => vehicle.make === "tesla");
console.log("Filter WITH ARROW", vehicleArrowFind);

// EVERY - does every arr obj have certain value(s)?
let areAllAWD = vehicles.every(function(vehicle){
  return vehicle.isAWD === true;
})
console.log("EVERY search applied to AWD vehicles RETURNS:", areAllAWD);

// SOME = allows you to search for 'some' vehicles with certain value(s)
// arrow function example
let areSomeAWD = vehicles.some(vehicle => vehicle.isAWD === true);
console.log("are some vehicles AWD? RETURNS:", areSomeAWD);


// FOR LOOP - (example prior to REDUCE)
let gradesArr = [94,89,99,22,15,107];
let sumTwo = 0;
for(x = 0; x < gradesArr.length; x++){
  sumTwo += gradesArr[x];
}
console.log("sum of grades pre-REDUCE:", sumTwo);
console.log("avg of grades pre-REDUCE:", sumTwo / gradesArr.length);
console.log(`Our average (in string literal form) is ${(sum / grades.length).toFixed(1)}`);

// REDUCE EXAMPLE !!! (no arrow function)
// let total = grades.reduce(function(sum,grade) {
//   return sum + grade;
// }, 0);

// console.log(`Our total = ${total}`);
// console.log(`Our average (using REDUCE) is ${(total / gradesArr.length).toFixed(1)}`);


// REDUCE EXAMPLE !!! USING ARROW FUNCTIONS ES6 SYNTAX
let total = gradesArr.reduce((sumTwo, gradesArr) => {
  return sumTwo + gradesArr;
}, 0);

console.log(`Our total = ${total}`);
console.log(`Our average (using REDUCE) is ${(total / gradesArr.length).toFixed(1)}`);

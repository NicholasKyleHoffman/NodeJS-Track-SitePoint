// export below & import in importAndRequire.js
export let myVar = 942;
export let func1 = () => {
  console.log('Hello from func1');
}
export let func2 = () => {
  console.log('Hello from func2');
}



// in JS you gain access to files with EXPORT - OLD SYNTAX
// let myVar = 942;
// let func1 = () => {
//   console.log('Hello from func1');
// }
// let func2 = () => {
//   console.log('Hello from func2');
// }

// OR - define module.exports here
// module.exports.myVar = 942;
// module.exports.func1 = () => {
//   console.log('Hello from func1');
// }
// module.exports.func2 = () => {
//   console.log('Hello from func2');
// }

// OLD SYNTAX
// module.exports.SOMETHING = someName;
// ^ can use in another file (importAndRequire.js)
// below module.exports can be put into a single OBJECT
// module.exports.myVar = myVar;
// module.exports.func1 = func1;
// module.exports.func2 = func2;

// OBJECT EXAMPLE FOR exports
// module.exports = {
//   myVariable: myVar,
//   func1: func1,
//   func2: func2
// };

let grades = [92, 84, 22];

console.log(`my first grade is ${grades[0]}`);

let myStuff = ['baseball', '32', 'true'];
console.log(myStuff.length);

// array methods
// pop - remove from end of arr
let poppedVal = myStuff.pop();
console.log("pop - rmv from end" + " " + poppedVal);
console.log(myStuff);

// PUSH - add to end of arr
myStuff.push(poppedVal);
// console.log((poppedVal));
console.log(myStuff);

console.log(grades);
grades.push(72, 9, 0);
console.log(grades);

//SHIFT @ beginning of arr
let shiftedVale = myStuff.shift();
console.log(shiftedVale);
console.log(myStuff);

// CONCAT
let arrC = [1,3,4];
let arrD = [4,3,2];
let concatArr = arrC.concat(arrD);
console.log(concatArr);
//OR
console.log(arrC[0]+arrC[2]);

// REVERSE
let revArr = arrC.reverse();
console.log(revArr);

// SORTs alphabetically
let statesArr = ['tx','ny','co','ca','az'];
let sortedArr = statesArr.sort();
console.log(sortedArr);

// SORTs numerically
let numArr = [7123, 2, 0, 5, 21];
let sortedNumArr = numArr.sort();
//OR
let sortNumArr = numArr.sort(function(a,b){
  return a - b;
});
console.log(sortNumArr);
console.log(sortedNumArr);

// SLICE
// allows you to remove a SLICE of an array. Two vals - start index & end index. reTurns everything in btwn.
let sliceArr = [4,5,1,2,5,2,34,95];
let slice = sliceArr.slice(1,5);
console.log(slice);
